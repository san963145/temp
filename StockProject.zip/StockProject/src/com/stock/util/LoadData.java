package com.stock.util;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

import com.stock.dao.StockDao;
import com.stock.daoImpl.StockDaoImpl;
import com.stock.model.Stock;



public class LoadData {
	
	public static void main(String[] args){
		
		SparkConf conf=new SparkConf().setMaster("local").setAppName("Spark Test");
		JavaSparkContext sc=new JavaSparkContext(conf);
		
		JavaRDD<String> rdd=sc.textFile("I:\\test1\\QQuoteData\\allstocks_2016*\\*.csv");
		
		System.out.println(rdd.count());
		
		/*StockDao stockDao=new StockDaoImpl();
		rdd.foreach(x->{
			String[] s=x.split(",");
			Stock stock=new Stock(s);
			stockDao.add(stock);
		});*/
		/*SQLContext sqlContext=new SQLContext(sc);
		
		String jdbcUrl   = "jdbc:oracle:thin:@fxdspmwdb1d.nam.nsroot.net:2523:DSPDBD5";
				
		java.util.Properties connectionProperties = new java.util.Properties();
		connectionProperties.put("driver", "oracle.jdbc.driver.OracleDriver");
		connectionProperties.put("user", "DSP_DBO");
		connectionProperties.put("password", "dsp24dbo");
        DataFrame df=sqlContext.read().jdbc(jdbcUrl, "ZL18625_SIMPLESERVICE", connectionProperties);
        
        
		String[] s=df.columns();
		System.out.println(s[0]);*/
	}

}
