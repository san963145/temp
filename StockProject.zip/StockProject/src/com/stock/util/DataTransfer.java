package com.stock.util;



import java.util.List;

import com.stock.model.Stock;

public class DataTransfer {
	
	public static String generateDailyData(List<Stock>list){
		
		StringBuilder st=new StringBuilder();
		st.append("[");
		int n=list.size();
		for(int i=n-1;i>=0;i--)
		{
			Stock s=list.get(i);
			StringBuilder date=new StringBuilder(s.getDate());
			
			//
			st.append("[");
			st.append("'"+date+"',");
			st.append("'"+s.getOpen()+"',");
			st.append("'"+s.getClose()+"',");
			st.append("'"+s.getLow()+"',");
			st.append("'"+s.getHigh()+"'");
			st.append("],");
		}
		st.append("]");
		return st.toString();
		
	}

}
