package com.stock.controller;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.stock.dao.StockDao;
import com.stock.daoImpl.StockDaoImpl;
import com.stock.model.Stock;


@Controller
@RequestMapping("/minute")
public class StatisticsByMinute {
	
	@RequestMapping(value="search",method={RequestMethod.POST})
	public ModelAndView search(@RequestParam("stock") String stock,@RequestParam("date") String date){		
		
		String result="isEmpty";
		ModelAndView mv = new ModelAndView();		
		StockDao dao=new StockDaoImpl();
		ArrayList<Stock> list=dao.getByNameDate(stock, date);
		if(list.size()>0)
		{
			result="notEmpty";
		}
		mv.addObject("result", result);
		mv.addObject("stock", stock);
		mv.addObject("date", date);
		mv.addObject("list", list);
		mv.setViewName("statisticsByMinutes");				
		return mv;
	}
	
	@RequestMapping(value="url",method={RequestMethod.GET})
	public ModelAndView searchByURL(@RequestParam("stock") String stock,@RequestParam("date") String date){		
		
		String result="isEmpty";
		ModelAndView mv = new ModelAndView();		
		StockDao dao=new StockDaoImpl();
		ArrayList<Stock> list=dao.getByNameDate(stock, date);
		if(list.size()>0)
		{
			result="notEmpty";
		}
		mv.addObject("result", result);
		mv.addObject("stock", stock);
		mv.addObject("date", date);
		mv.addObject("list", list);
		mv.setViewName("statisticsByMinutes");				
		return mv;
	}

}
