package com.stock.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.stock.dao.StockDao;
import com.stock.daoImpl.StockDaoImpl;
import com.stock.model.Stock;
import com.stock.util.DataTransfer;

@Controller
@RequestMapping("/day")
public class StatisticsByDay {
	
	@RequestMapping(value="search",method={RequestMethod.POST})
	public ModelAndView search(@RequestParam("stock") String stock,@RequestParam("dateStart") String dateStart,@RequestParam("dateEnd") String dateEnd,HttpServletRequest request){		
		
		String result="isEmpty";
		ModelAndView mv = new ModelAndView();	
		dateStart=dateStart.replaceAll("-", "");
		dateEnd=dateEnd.replaceAll("-", "");
		StockDao dao=new StockDaoImpl();
		List<Stock> list=dao.getByStartAndEndDay(stock, dateStart, dateEnd);
		String data=DataTransfer.generateDailyData(list);
		if(list.size()>0)
		{
			result="notEmpty";
		}
		mv.addObject("result", result);
		mv.addObject("stock", stock);
		mv.addObject("dateStart", dateStart);
		mv.addObject("dateEnd", dateEnd);
		mv.addObject("data", data);
		request.setAttribute("data", data);
		mv.setViewName("statisticsByDays");				
		return mv;
	}

}
