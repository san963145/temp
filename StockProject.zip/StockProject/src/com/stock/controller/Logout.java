package com.stock.controller;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class Logout {
	
	@RequestMapping("/logout")
	public String logout(HttpServletRequest request, HttpServletResponse response,HttpSession session){
		
		Cookie[] cookies=request.getCookies();
		if(cookies!=null)
		{
		   for(Cookie c : cookies)
		   {
				c.setMaxAge(0);
				response.addCookie(c);
		   }
		}
		session.invalidate();
		System.out.println(request.getRealPath("/"));
		return "index";
	}

}
