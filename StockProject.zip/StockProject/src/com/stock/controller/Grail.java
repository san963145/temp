package com.stock.controller;



import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.stock.dao.StockDao;
import com.stock.daoImpl.StockDaoImpl;
import com.stock.model.Stock;

@Controller
@RequestMapping("/grail")
public class Grail {
	
	@RequestMapping(value="get",method={RequestMethod.GET})
	public ModelAndView get(){
		
		String result="isEmpty";
		ModelAndView mv = new ModelAndView();		
		StockDao dao=new StockDaoImpl();
		List<Stock> list=dao.getGrail();
		String date=null;
		if(list.size()>0)
		{
			result="notEmpty";
			date=list.get(0).getDate();
			
		}		
		mv.addObject("result", result);
		mv.addObject("list", list);
		mv.addObject("date", date);
		mv.setViewName("grail");				
		return mv;
	}

}
