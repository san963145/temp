package com.stock.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.stock.model.User;

@Controller
@RequestMapping("/login")
public class Login {
	
	
	@RequestMapping(value="check",method={RequestMethod.POST})
	public ModelAndView loginCheck(@RequestParam("username") String a,@RequestParam("password") String b,HttpSession session){		
		
		String result="error";
		ModelAndView mv = new ModelAndView();
		
		
		///  dao
		
		result="correct";
		mv.addObject("result", result);
		if(result.equals("error"))
		{
			mv.setViewName("index");
		}
		else
		{
			User user=new User(a,b);
			session.setAttribute("user", user);
			mv.addObject("user",user);
			mv.setViewName("main");
		}		
		return mv;
	}
	
	

}
