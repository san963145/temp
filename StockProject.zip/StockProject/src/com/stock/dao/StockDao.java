package com.stock.dao;

import java.util.ArrayList;
import java.util.List;

import com.stock.model.Stock;

public interface StockDao {
	
	public void add(Stock stock);
	public ArrayList<Stock> getByName(String name);
	public ArrayList<Stock> getByNameDate(String name,String date);
	
	public List<Stock> getByStartAndEndDay(String name,String dateStart,String dateEnd);
	
	public List<Stock> getGrail();

}
