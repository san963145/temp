package com.stock.dao;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.commons.dbcp.BasicDataSource;

public class DataSource {
	
	    private static DataSource     datasource;
	    private BasicDataSource ds;

	    public final static String DRIVER_NAME="oracle.jdbc.driver.OracleDriver";
		public final static String DB_URL="jdbc:oracle:thin:@fxdspmwdb1d.nam.nsroot.net:2523:DSPDBD5";
		public final static String DB_USER="DSP_DBO";
		public final static String DB_PASSWORD="dsp24dbo";
		
	    private DataSource() throws Exception {
	        ds = new BasicDataSource();
	        ds.setDriverClassName(DRIVER_NAME);
	        ds.setUsername(DB_USER);
	        ds.setPassword(DB_PASSWORD);
	        ds.setUrl(DB_URL);
	       
	        // the settings below are optional -- dbcp can work with defaults
	        ds.setMinIdle(5);
	        ds.setMaxIdle(20);
	        ds.setMaxOpenPreparedStatements(180);

	    }

	    public static DataSource getInstance() throws Exception {
	        if (datasource == null) {
	            datasource = new DataSource();
	            return datasource;
	        } else {
	            return datasource;
	        }
	    }

	    public Connection getConnection() throws SQLException {
	        return this.ds.getConnection();
	    }

}
