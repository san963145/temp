
package com.stock.model;
 

 
 

import java.io.Serializable;
 

import java.sql.Date;
 

 
 

 
 

public class Stock implements Serializable{
 

    private String symbol;
 

    private String recorddate;
 

    private String time;
 

    private double open;
 

    private double high;
 

    private double low;
 

    private double close;
 

    private double volumn;
 

    private double splitfactor;
 

    private int earnings;
 

    private double dividends;
 

    
 

    public Stock(){
    	
    }
 

    public Stock(String symbol, String recorddate, String time, double open, double high,
 

            double low, double close, double volumn, double splitfactor,
 

            int earnings, double dividends) {
 

        super();
 

        this.symbol = symbol;
 

        this.recorddate = recorddate;
 

        this.time = time;
 

        this.open = open;
 

        this.high = high;
 

        this.low = low;
 

        this.close = close;
 

        this.volumn = volumn;
 

        this.splitfactor = splitfactor;
 

        this.earnings = earnings;
 

        this.dividends = dividends;
 

    }
 

    
 

 
 

    @Override
 

    public String toString() {
 

        return "Stock [symbol=" + symbol + ", recorddate=" + recorddate
 

                + ", time=" + time + ", open=" + open + ", high=" + high
 

                + ", low=" + low + ", close=" + close + ", volumn=" + volumn
 

                + ", splitfactor=" + splitfactor + ", earnings=" + earnings
 

                + ", dividends=" + dividends + "]";
 

    }
 

 
 

 
 

    public String getSymbol() {
 

        return symbol;
 

    }
 

    public void setSymbol(String symbol) {
 

        this.symbol = symbol;
 

    }
 

    public String getDate() {
 

        return recorddate;
 

    }
 

    public void setDate(String date) {
 

        this.recorddate = date;
 

    }
 

    public String getTime() {
 

        return time;
 

    }
 

    public void setTime(String time) {
 

        this.time = time;
 

    }
 

    public double getOpen() {
 

        return open;
 

    }
 

    public void setOpen(double open) {
 

        this.open = open;
 

    }
 

    public double getHigh() {
 

        return high;
 

    }
 

    public void setHigh(double high) {
 

        this.high = high;
 

    }
 

    public double getLow() {
 

        return low;
 

    }
 

    public void setLow(double low) {
 

        this.low = low;
 

    }
 

    public double getClose() {
 

        return close;
 

    }
 

    public void setClose(double close) {
 

        this.close = close;
 

    }
 

    public double getVolumn() {
 

        return volumn;
 

    }
 

    public void setVolumn(int volumn) {
 

        this.volumn = volumn;
 

    }
 

    public double getSpliftfactor() {
 

        return splitfactor;
 

    }
 

    public void setSpliftfactor(double spliftfactor) {
 

        this.splitfactor = spliftfactor;
 

    }
 

    public int getEarnings() {
 

        return earnings;
 

    }
 

    public void setEarnings(int earnings) {
 

        this.earnings = earnings;
 

    }
 

    public double getDividends() {
 

        return dividends;
 

    }
 

    public void setDividends(double dividends) {
 

        this.dividends = dividends;
 

    }
 

    
 

} 
