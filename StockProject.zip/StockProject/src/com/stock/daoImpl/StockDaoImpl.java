package com.stock.daoImpl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.stock.dao.DataSource;
import com.stock.dao.StockDao;
import com.stock.model.Stock;

public class StockDaoImpl implements StockDao{

	@Override
	public void add(Stock stock) {
		// TODO Auto-generated method stub
		Connection conn=null;	    	    	
		try {
			conn = DataSource.getInstance().getConnection();
			conn.setAutoCommit(false);
			PreparedStatement statement = conn.prepareStatement("insert into STOCKINFO_2016 values(?,?,?,?,?,?,?,?,?,?,?)");
			statement.setString(1, stock.getSymbol());
			statement.setString(2, stock.getDate());
			statement.setString(3, stock.getTime());
			statement.setDouble(4, stock.getOpen());
			statement.setDouble(5, stock.getHigh());
			statement.setDouble(6, stock.getLow());
			statement.setDouble(7, stock.getClose());
			statement.setDouble(8, stock.getVolumn());
			statement.setDouble(9, stock.getSpliftfactor());
			statement.setInt(10, stock.getEarnings());
			statement.setDouble(11, stock.getDividends());
			statement.executeUpdate();		
			statement.close();
			conn.commit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static String getDevice(String ip) throws Exception
    {
    	Connection conn = null;
    	conn=DataSource.getInstance().getConnection();
    	PreparedStatement statement = conn.prepareStatement("select status from ZL18625_SIMPLESERVICE where ip=?");
		statement.setString(1, ip);
		
		ResultSet rs = statement.executeQuery();
		
		if(rs.next()){
			return rs.getString(1);
		}
		else
		{
			return null;
		}
		
    }
	public static void main(String[] args) throws Exception
	{
		StockDao dao=new StockDaoImpl();
		File file=new File("I:\\test1\\QQuoteData");
		File[] files=file.listFiles();
		for(int i=0;i<files.length;i++)
		{
			File[] f=files[i].listFiles();
			for(int j=0;j<f.length;j++)
			{
				BufferedReader r=new BufferedReader(new FileReader(f[j]));
				String line=r.readLine();
				while(line!=null)
				{
					String[] s=line.split(",");
					Stock stock=new Stock();
					dao.add(stock);
				}
				r.close();
			}
		}
	}
	@Override
	public ArrayList<Stock> getByName(String name) {
		// TODO Auto-generated method stub
		
			return new ArrayList<Stock>();
		
    	
		
	}
	@Override
	public ArrayList<Stock> getByNameDate(String name, String date) {
		// TODO Auto-generated method stub
		ArrayList<Stock> list=new ArrayList<Stock>();
		
		Stock s1=new Stock("a","2016-08-03","10:20",35.1,36.2,34.5,35.7,1200,1,0,0);
		Stock s12=new Stock("a","2016-08-04","10:22",35.1,36.4,34.2,35.7,1200,1,0,0);
		Stock s13=new Stock("a","2016-08-05","10:23",35.1,36.6,34.2,35.7,1200,1,0,0);
		Stock s14=new Stock("a","2016-08-06","10:25",35.1,36.0,34.1,35.7,1200,1,0,0);
		Stock s15=new Stock("a","2016-08-07","10:26",35.1,35.8,34.2,35.7,1200,1,0,0);
		Stock s16=new Stock("a","2016-08-08","10:27",35.1,35.8,34.0,35.7,1200,1,0,0);
		Stock s17=new Stock("a","2016-08-09","10:28",35.1,36.1,34.3,35.7,1200,1,0,0);
		Stock s18=new Stock("a","2016-08-10","10:29",35.1,36.2,34.5,35.7,1200,1,0,0);
		Stock s19=new Stock("a","2016-08-11","10:30",35.1,36.6,34.2,35.7,1200,1,0,0);
		Stock s110=new Stock("a","2016-08-12","10:31",35.1,36.2,34.5,35.7,1200,1,0,0);
		list.add(s1);
		list.add(s12);
		list.add(s13);
		list.add(s14);
		list.add(s15);
		list.add(s16);
		list.add(s17);
		list.add(s18);
		list.add(s19);
		list.add(s110);
		return list;
	}
	
	@Override
	public List<Stock> getByStartAndEndDay(String name, String dateStart, String dateEnd) {
		// TODO Auto-generated method stub
ArrayList<Stock> list=new ArrayList<Stock>();
		
		Stock s1=new Stock("a","2016-08-03","10:20",35.1,36.2,34.5,35.7,1200,1,0,0);
		Stock s12=new Stock("a","2016-08-04","10:22",35.1,36.4,34.2,35.7,1200,1,0,0);
		Stock s13=new Stock("a","2016-08-05","10:23",35.1,36.6,34.2,35.7,1200,1,0,0);
		Stock s14=new Stock("a","2016-08-06","10:25",35.1,36.0,34.1,35.7,1200,1,0,0);
		Stock s15=new Stock("a","2016-08-07","10:26",35.1,35.8,34.2,35.7,1200,1,0,0);
		Stock s16=new Stock("a","2016-08-08","10:27",35.1,35.8,34.0,35.7,1200,1,0,0);
		Stock s17=new Stock("a","2016-08-09","10:28",35.1,36.1,34.3,35.7,1200,1,0,0);
		Stock s18=new Stock("a","2016-08-10","10:29",35.1,36.2,34.5,35.7,1200,1,0,0);
		Stock s19=new Stock("a","2016-08-11","10:30",35.1,36.6,34.2,35.7,1200,1,0,0);
		Stock s110=new Stock("a","2016-08-12","10:31",35.1,36.2,34.5,35.7,1200,1,0,0);
		list.add(s1);
		list.add(s12);
		list.add(s13);
		list.add(s14);
		list.add(s15);
		list.add(s16);
		list.add(s17);
		list.add(s18);
		list.add(s19);
		list.add(s110);
		return list;
	}
	@Override
	public List<Stock> getGrail() {
		// TODO Auto-generated method stub
ArrayList<Stock> list=new ArrayList<Stock>();
		
		Stock s1=new Stock("a","2016-08-03","10:20",35.1,36.2,34.5,35.7,1200,1,0,0);
		Stock s12=new Stock("b","2016-08-03","10:22",35.1,36.4,34.2,35.7,1200,1,0,0);
		Stock s13=new Stock("c","2016-08-03","10:23",35.1,36.6,34.2,35.7,1200,1,0,0);
		Stock s14=new Stock("d","2016-08-03","10:25",35.1,36.0,34.1,35.7,1200,1,0,0);
		Stock s15=new Stock("e","2016-08-03","10:26",35.1,35.8,34.2,35.7,1200,1,0,0);
		Stock s16=new Stock("f","2016-08-03","10:27",35.1,35.8,34.0,35.7,1200,1,0,0);
		Stock s17=new Stock("g","2016-08-03","10:28",35.1,36.1,34.3,35.7,1200,1,0,0);
		Stock s18=new Stock("h","2016-08-03","10:29",35.1,36.2,34.5,35.7,1200,1,0,0);
		Stock s19=new Stock("i","2016-08-03","10:30",35.1,36.6,34.2,35.7,1200,1,0,0);
		Stock s110=new Stock("j","2016-08-03","10:31",35.1,36.2,34.5,35.7,1200,1,0,0);
		list.add(s1);
		list.add(s12);
		list.add(s13);
		list.add(s14);
		list.add(s15);
		list.add(s16);
		list.add(s17);
		list.add(s18);
		list.add(s19);
		list.add(s110);
		return list;
	}

}
